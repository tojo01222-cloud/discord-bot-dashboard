"""
Zusätzliche Server-Dashboard-Seiten (über die Basis-Einstellungen hinaus):

- /dashboard/{id}/team              -- Team-Ränge + Mitgliederliste (Ansicht)
- /dashboard/{id}/levelrollen         -- Level-Rang-Rollen verwalten
- /dashboard/{id}/vertrauensliste      -- Anti-Nuke-Whitelist verwalten
- /dashboard/{id}/gewinnspiele           -- laufende/beendete Gewinnspiele (Ansicht)
- /dashboard/{id}/strafen                 -- aktives Strafverzeichnis (Ansicht)
- /dashboard/{id}/leaderboard               -- XP-Bestenliste (Ansicht)
"""
from fastapi import APIRouter, Request, Form
from fastapi.responses import RedirectResponse, HTMLResponse
import asyncio
from fastapi.templating import Jinja2Templates

from bot.utils.db_helpers import (
    get_team_ranks,
    add_team_rank,
    remove_team_rank,
    get_all_team_members,
    get_level_role_rewards,
    add_level_role_reward,
    remove_level_role_reward,
    get_trusted_users,
    add_trusted_user,
    remove_trusted_user,
    get_giveaways_for_guild,
    get_guild_punishments,
    get_leaderboard,
    log_punishment,
    get_or_create_guild_settings,
    get_tickets_for_guild,
    add_anti_exemption,
    remove_anti_exemption,
    get_anti_exemptions,
    get_ad_channel,
    set_ad_channel,
    add_partner,
    get_partners,
    remove_partner,
    get_reaction_roles,
    remove_reaction_role,
    get_suggestion_channel,
    set_suggestion_channel,
    get_suggestions,
    update_suggestion_status,
    get_birthday_channel,
    set_birthday_channel,
    get_birthdays_for_guild,
    get_economy_leaderboard,
    get_shop_items,
    add_shop_item,
    remove_shop_item,
    get_ticket_categories,
    create_ticket_category,
    delete_ticket_category,
    count_open_tickets_by_category,
    set_waiting_room_message,
    get_welcome_config,
    set_welcome_config,
    get_timed_autoroles,
    add_timed_autorole,
    remove_timed_autorole,
    get_verification_config,
    set_verification_config,
    get_dashboard_audit_log,
    get_daily_activity,
    create_poll,
    set_poll_message_id,
    get_polls,
    get_poll_results,
)
import json as _json_srv
from bot.database.db import get_session
from dashboard.backend.bot_api import (
    fetch_guild_roles, fetch_guild_text_channels, kick_member, ban_member, send_channel_message,
    fetch_guild_members, add_role_to_member,
    send_ticket_panel, fetch_guild_categories,
    send_channel_embed_get_id, add_message_reaction,
)
from dashboard.backend.template_context import global_template_context

server_extra_router = APIRouter()
templates = Jinja2Templates(directory="dashboard/backend/templates", context_processors=[global_template_context])


def _current_user(request: Request):
    return request.session.get("user")


async def _require_guild_admin(request: Request, guild_id: int):
    """Lokaler Import, um einen Ringimport mit main.py zu vermeiden (siehe
    application_routes.py, gleiches Muster)."""
    from dashboard.backend.main import _require_guild_access
    return await _require_guild_access(request, guild_id)


@server_extra_router.get("/dashboard/{guild_id}/team", response_class=HTMLResponse)
async def team_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    ranks = await get_team_ranks(guild_id)
    members = await get_all_team_members(guild_id)
    ranks_by_id = {r.id: r for r in ranks}
    roles = await fetch_guild_roles(guild_id)
    return templates.TemplateResponse(request, "dash_team.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "ranks": ranks, "members": members, "ranks_by_id": ranks_by_id, "roles": roles,
    })


@server_extra_router.post("/dashboard/{guild_id}/team/raenge")
async def team_rank_add(request: Request, guild_id: int, role_id: int = Form(...)):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    if role_id:
        await add_team_rank(guild_id, role_id)
    return RedirectResponse(f"/dashboard/{guild_id}/team", status_code=303)


@server_extra_router.post("/dashboard/{guild_id}/team/raenge/{rank_id}/loeschen")
async def team_rank_remove(request: Request, guild_id: int, rank_id: int):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    await remove_team_rank(rank_id)
    return RedirectResponse(f"/dashboard/{guild_id}/team", status_code=303)


@server_extra_router.get("/dashboard/{guild_id}/levelrollen", response_class=HTMLResponse)
async def level_roles_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    rewards = await get_level_role_rewards(guild_id)
    roles = await fetch_guild_roles(guild_id)
    return templates.TemplateResponse(request, "dash_levelrollen.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "rewards": rewards, "roles": roles,
    })


@server_extra_router.post("/dashboard/{guild_id}/levelrollen")
async def level_roles_add(request: Request, guild_id: int, level: int = Form(...), role_id: int = Form(...)):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    if role_id:
        await add_level_role_reward(guild_id, level, role_id)
    return RedirectResponse(f"/dashboard/{guild_id}/levelrollen", status_code=303)


@server_extra_router.post("/dashboard/{guild_id}/levelrollen/{reward_id}/loeschen")
async def level_roles_remove(request: Request, guild_id: int, reward_id: int):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    await remove_level_role_reward(reward_id)
    return RedirectResponse(f"/dashboard/{guild_id}/levelrollen", status_code=303)


@server_extra_router.get("/dashboard/{guild_id}/vertrauensliste", response_class=HTMLResponse)
async def trusted_users_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    trusted = await get_trusted_users(guild_id)
    return templates.TemplateResponse(request, "dash_vertrauensliste.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "trusted": trusted,
    })


@server_extra_router.post("/dashboard/{guild_id}/vertrauensliste")
async def trusted_users_add(request: Request, guild_id: int, discord_id: int = Form(...)):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    user = _current_user(request)
    await add_trusted_user(guild_id, discord_id, int(user["discord_id"]))
    return RedirectResponse(f"/dashboard/{guild_id}/vertrauensliste", status_code=303)


@server_extra_router.post("/dashboard/{guild_id}/vertrauensliste/{discord_id}/entfernen")
async def trusted_users_remove(request: Request, guild_id: int, discord_id: int):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    await remove_trusted_user(guild_id, discord_id)
    return RedirectResponse(f"/dashboard/{guild_id}/vertrauensliste", status_code=303)


@server_extra_router.get("/dashboard/{guild_id}/gewinnspiele", response_class=HTMLResponse)
async def giveaways_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    giveaways = await get_giveaways_for_guild(guild_id)
    return templates.TemplateResponse(request, "dash_gewinnspiele.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "giveaways": giveaways,
    })


@server_extra_router.get("/dashboard/{guild_id}/strafen", response_class=HTMLResponse)
async def punishments_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    punishments = await get_guild_punishments(guild_id)
    return templates.TemplateResponse(request, "dash_strafen.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "punishments": punishments,
    })


@server_extra_router.get("/dashboard/{guild_id}/leaderboard", response_class=HTMLResponse)
async def leaderboard_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    top = await get_leaderboard(guild_id, limit=25)
    return templates.TemplateResponse(request, "dash_leaderboard.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "top": top,
    })


@server_extra_router.get("/dashboard/{guild_id}/moderation", response_class=HTMLResponse)
async def moderation_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    roles = await fetch_guild_roles(guild_id)
    return templates.TemplateResponse(request, "dash_moderation.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "roles": roles,
    })


async def _moderation_context(guild_id: int) -> dict:
    """Rollen fürs Moderation-Formular (nur noch für Autorole-an-alle nötig,
    seit Slowmode/Lock/Nickname entfernt wurden -- an einer Stelle, damit
    nicht jede moderation_*-Route das einzeln wiederholen muss)."""
    roles = await fetch_guild_roles(guild_id)
    return {"roles": roles}


@server_extra_router.post("/dashboard/{guild_id}/moderation/kick")
async def moderation_kick(request: Request, guild_id: int, user_id: int = Form(...),
                           reason: str = Form("Kein Grund angegeben")):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    # Hinweis: dieser Weg umgeht die Rollen-Hierarchie-Prüfung der Discord-Befehle
    # (/kick) -- der Zugriff aufs Dashboard selbst ist aber schon durch die
    # Discord-"Manage Server"-Berechtigung für GENAU diesen Server abgesichert.
    ok = await kick_member(guild_id, user_id, reason)
    return templates.TemplateResponse(request, "dash_moderation.html", {
        "user": _current_user(request),
        "guild": {"id": guild_id, "name": guild["name"]},
        **(await _moderation_context(guild_id)),
        "messages": [{"type": "success" if ok else "error",
                      "text": "User gekickt." if ok else "Kick fehlgeschlagen (Berechtigung des Bots prüfen)."}],
    })


@server_extra_router.post("/dashboard/{guild_id}/moderation/ban")
async def moderation_ban(request: Request, guild_id: int, user_id: int = Form(...),
                          reason: str = Form("Kein Grund angegeben")):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    ok = await ban_member(guild_id, user_id, reason)
    return templates.TemplateResponse(request, "dash_moderation.html", {
        "user": _current_user(request),
        "guild": {"id": guild_id, "name": guild["name"]},
        **(await _moderation_context(guild_id)),
        "messages": [{"type": "success" if ok else "error",
                      "text": "User gebannt." if ok else "Bann fehlgeschlagen (Berechtigung des Bots prüfen)."}],
    })


@server_extra_router.post("/dashboard/{guild_id}/moderation/warn")
async def moderation_warn(request: Request, guild_id: int, user_id: int = Form(...),
                           reason: str = Form("Kein Grund angegeben")):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    user = _current_user(request)
    await log_punishment(guild_id, user_id, int(user["discord_id"]), "warn", reason)
    return templates.TemplateResponse(request, "dash_moderation.html", {
        "user": user,
        "guild": {"id": guild_id, "name": guild["name"]},
        **(await _moderation_context(guild_id)),
        "messages": [{"type": "success", "text": "Verwarnung gespeichert."}],
    })


@server_extra_router.post("/dashboard/{guild_id}/moderation/autorole-all")
async def moderation_autorole_all(request: Request, guild_id: int, role_id: int = Form(...)):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied

    members = await fetch_guild_members(guild_id)
    given, already_had, failed = 0, 0, 0
    for member in members:
        if member.get("user", {}).get("bot"):
            continue
        if str(role_id) in member.get("roles", []):
            already_had += 1
            continue
        ok = await add_role_to_member(guild_id, int(member["user"]["id"]), role_id, "Dashboard: Autorole an alle")
        if ok:
            given += 1
        else:
            failed += 1

    text = f"{given} Mitgliedern die Rolle gegeben. {already_had} hatten sie schon."
    if failed:
        text += f" {failed} fehlgeschlagen."
    return templates.TemplateResponse(request, "dash_moderation.html", {
        "user": _current_user(request),
        "guild": {"id": guild_id, "name": guild["name"]},
        **(await _moderation_context(guild_id)),
        "messages": [{"type": "success", "text": text}],
    })


# ---------- Ticket-Arten (Kategorien) + Panel senden ----------

DESIGN_COLORS = {"standard": 0x5865F2, "minimal": 0x99AAB5, "premium": 0xF1C40F, "dark": 0x1E1E28}
DESIGN_EMOJIS = {"standard": "🎫", "minimal": "✉️", "premium": "⭐", "dark": "🌑"}


@server_extra_router.get("/dashboard/{guild_id}/tickets/kategorien", response_class=HTMLResponse)
async def ticket_categories_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    categories = await get_ticket_categories(guild_id)
    # Live-Auslastung pro Kategorie mit anzeigen, genau wie im Panel selbst.
    categories_with_stats = []
    for c in categories:
        open_count = await count_open_tickets_by_category(c.id) if c.max_concurrent else 0
        categories_with_stats.append({"category": c, "open_count": open_count})
    # Gleichzeitig statt nacheinander abfragen (Performance).
    roles, categories_channel = await asyncio.gather(
        fetch_guild_roles(guild_id), fetch_guild_categories(guild_id),
    )
    return templates.TemplateResponse(request, "dash_ticket_kategorien.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "categories": categories_with_stats, "roles": roles, "discord_categories": categories_channel,
    })


@server_extra_router.post("/dashboard/{guild_id}/tickets/kategorien")
async def ticket_categories_add(
    request: Request, guild_id: int, name: str = Form(...), emoji: str = Form("🎫"),
    description: str = Form(""), max_concurrent: int = Form(0), ping_role_id: int = Form(0),
    channel_category_id: int = Form(0),
):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    if name.strip():
        await create_ticket_category(
            guild_id, name=name.strip(), emoji=emoji or "🎫", description=description,
            channel_category_id=channel_category_id, max_concurrent=max(0, max_concurrent),
            ping_role_id=ping_role_id,
        )
    return RedirectResponse(f"/dashboard/{guild_id}/tickets/kategorien", status_code=303)


@server_extra_router.post("/dashboard/{guild_id}/tickets/kategorien/{category_id}/loeschen")
async def ticket_categories_remove(request: Request, guild_id: int, category_id: int):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    await delete_ticket_category(category_id)
    return RedirectResponse(f"/dashboard/{guild_id}/tickets/kategorien", status_code=303)


@server_extra_router.get("/dashboard/{guild_id}/tickets/panel-senden", response_class=HTMLResponse)
async def ticket_panel_send_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    channels = await fetch_guild_text_channels(guild_id)
    categories = await get_ticket_categories(guild_id)
    return templates.TemplateResponse(request, "dash_ticket_panel_senden.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "channels": channels, "categories": categories, "designs": list(DESIGN_COLORS.keys()),
    })


@server_extra_router.post("/dashboard/{guild_id}/tickets/panel-senden")
async def ticket_panel_send_submit(request: Request, guild_id: int, channel_id: int = Form(...),
                                    design: str = Form("standard")):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied

    categories = await get_ticket_categories(guild_id)
    channels = await fetch_guild_text_channels(guild_id)

    # Dieselbe Embed-Struktur wie /ticketpanel send in Discord selbst (siehe
    # bot/cogs/tickets.py, _build_panel_embed) -- hier als reines JSON-Dict
    # nachgebaut, da das Dashboard discord.py nicht direkt nutzt (nur REST).
    lines = []
    options = []
    for c in categories[:25]:
        line = f"{c.emoji} **{c.name}**" + (f"\n> {c.description}" if c.description else "")
        if c.max_concurrent:
            open_count = await count_open_tickets_by_category(c.id)
            available = max(0, c.max_concurrent - open_count)
            percent = round((available / c.max_concurrent) * 100)
            line += f"\n> Verfügbar: {available}/{c.max_concurrent} ({percent}%)"
        lines.append(line)
        options.append({
            "label": c.name[:100], "value": str(c.id),
            "description": (c.description or "")[:100] or None, "emoji": {"name": c.emoji} if c.emoji else None,
        })

    embed = {
        "title": f"{DESIGN_EMOJIS.get(design, '🎫')} Support-Ticket",
        "description": "Klicke auf den Button unten, um ein privates Ticket mit unserem Team zu öffnen.\n" + ("─" * 28),
        "color": DESIGN_COLORS.get(design, DESIGN_COLORS["standard"]),
        "footer": {"text": "Support-Team"},
    }
    if lines:
        embed["fields"] = [{"name": "📂 Verfügbare Ticket-Arten", "value": "\n".join(lines), "inline": False}]

    if not options:
        # Keine Ticket-Arten eingerichtet -- ohne Kategorien kann kein Auswahlmenü
        # gesendet werden (Discord erlaubt keine leeren Select-Menüs).
        return templates.TemplateResponse(request, "dash_ticket_panel_senden.html", {
            "user": _current_user(request), "guild": {"id": guild_id, "name": guild["name"]},
            "channels": channels, "categories": categories, "designs": list(DESIGN_COLORS.keys()),
            "messages": [{"type": "error", "text": "Richte zuerst mindestens eine Ticket-Art ein, bevor du "
                                                     "ein Panel sendest."}],
        })

    ok = await send_ticket_panel(channel_id, embed, options)
    return templates.TemplateResponse(request, "dash_ticket_panel_senden.html", {
        "user": _current_user(request), "guild": {"id": guild_id, "name": guild["name"]},
        "channels": channels, "categories": categories, "designs": list(DESIGN_COLORS.keys()),
        "messages": [{"type": "success" if ok else "error",
                      "text": "Panel gesendet." if ok else "Senden fehlgeschlagen (Berechtigung des Bots prüfen)."}],
    })


# ---------- Warteraum-Nachricht ----------

@server_extra_router.post("/dashboard/{guild_id}/warteraum-nachricht")
async def warteraum_message_save(request: Request, guild_id: int, message: str = Form("")):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    await set_waiting_room_message(guild_id, message.strip())
    return RedirectResponse(f"/dashboard/{guild_id}", status_code=303)


# ---------- Willkommen / Abschied ----------

@server_extra_router.get("/dashboard/{guild_id}/willkommen", response_class=HTMLResponse)
async def welcome_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    cfg = await get_welcome_config(guild_id)
    channels = await fetch_guild_text_channels(guild_id)
    return templates.TemplateResponse(request, "dash_willkommen.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "cfg": cfg, "channels": channels,
    })


@server_extra_router.post("/dashboard/{guild_id}/willkommen")
async def welcome_save(request: Request, guild_id: int, welcome_channel_id: int = Form(0),
                        welcome_message: str = Form(""), leave_channel_id: int = Form(0),
                        leave_message: str = Form("")):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    await set_welcome_config(
        guild_id, welcome_channel_id=welcome_channel_id, welcome_message=welcome_message,
        leave_channel_id=leave_channel_id, leave_message=leave_message,
    )
    return RedirectResponse(f"/dashboard/{guild_id}/willkommen", status_code=303)


# ---------- Zeit-Autorole ----------

@server_extra_router.get("/dashboard/{guild_id}/zeitautorole", response_class=HTMLResponse)
async def timed_autorole_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    entries = await get_timed_autoroles(guild_id)
    roles = await fetch_guild_roles(guild_id)
    return templates.TemplateResponse(request, "dash_zeitautorole.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "entries": entries, "roles": roles,
    })


@server_extra_router.post("/dashboard/{guild_id}/zeitautorole")
async def timed_autorole_add(request: Request, guild_id: int, role_id: int = Form(...), days: int = Form(...)):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    if days >= 1:
        await add_timed_autorole(guild_id, role_id, days)
    return RedirectResponse(f"/dashboard/{guild_id}/zeitautorole", status_code=303)


@server_extra_router.post("/dashboard/{guild_id}/zeitautorole/{entry_id}/loeschen")
async def timed_autorole_remove(request: Request, guild_id: int, entry_id: int):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    await remove_timed_autorole(entry_id)
    return RedirectResponse(f"/dashboard/{guild_id}/zeitautorole", status_code=303)


# ---------- Verifizierung ----------

@server_extra_router.get("/dashboard/{guild_id}/verifizierung", response_class=HTMLResponse)
async def verification_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    cfg = await get_verification_config(guild_id)
    channels = await fetch_guild_text_channels(guild_id)
    roles = await fetch_guild_roles(guild_id)
    return templates.TemplateResponse(request, "dash_verifizierung.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "cfg": cfg, "channels": channels, "roles": roles,
    })


@server_extra_router.post("/dashboard/{guild_id}/verifizierung")
async def verification_save(request: Request, guild_id: int, enabled: str = Form(""),
                             channel_id: int = Form(0), verified_role_id: int = Form(0)):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    await set_verification_config(
        guild_id, enabled=enabled == "on", channel_id=channel_id, verified_role_id=verified_role_id,
    )
    return RedirectResponse(f"/dashboard/{guild_id}/verifizierung", status_code=303)


# ---------- Audit-Log ----------

@server_extra_router.get("/dashboard/{guild_id}/audit-log", response_class=HTMLResponse)
async def audit_log_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    entries = await get_dashboard_audit_log(guild_id)
    return templates.TemplateResponse(request, "dash_audit_log.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "entries": entries,
    })


# ---------- Server-Statistik ----------

@server_extra_router.get("/dashboard/{guild_id}/statistik", response_class=HTMLResponse)
async def statistik_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    activity = await get_daily_activity(guild_id, days=14)
    return templates.TemplateResponse(request, "dash_statistik.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "activity": activity,
    })


# ---------- Suche ----------

@server_extra_router.get("/dashboard/{guild_id}/suche", response_class=HTMLResponse)
async def search_page(request: Request, guild_id: int, q: str = ""):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied

    results = {"members": [], "tickets": [], "punishments": []}
    if q.strip():
        query_lower = q.strip().lower()
        members = await get_all_team_members(guild_id)
        results["members"] = [m for m in members if query_lower in str(m.user_id)]
        tickets = await get_tickets_for_guild(guild_id)
        results["tickets"] = [t for t in tickets if query_lower in str(t.creator_id)]
        punishments = await get_guild_punishments(guild_id)
        results["punishments"] = [p for p in punishments if query_lower in str(p.user_id)
                                   or query_lower in (p.reason or "").lower()]

    return templates.TemplateResponse(request, "dash_suche.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "q": q, "results": results,
    })


# ---------- Umfragen (Dashboard-Erstellung) ----------

@server_extra_router.get("/dashboard/{guild_id}/umfragen", response_class=HTMLResponse)
async def polls_page(request: Request, guild_id: int):
    denied, guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    polls = await get_polls(guild_id)
    channels = await fetch_guild_text_channels(guild_id)
    polls_with_results = []
    for p in polls:
        options = _json_srv.loads(p.options_json)
        counts = await get_poll_results(p.id)
        polls_with_results.append({"poll": p, "options": options, "counts": counts,
                                    "total": sum(counts.values())})
    return templates.TemplateResponse(request, "dash_umfragen.html", {
        "user": _current_user(request), "messages": [],
        "guild": {"id": guild_id, "name": guild["name"]},
        "polls": polls_with_results, "channels": channels,
    })


@server_extra_router.post("/dashboard/{guild_id}/umfragen")
async def polls_create(request: Request, guild_id: int, channel_id: int = Form(...),
                        question: str = Form(...), options: str = Form(...)):
    denied, _guild = await _require_guild_admin(request, guild_id)
    if denied:
        return denied
    option_list = [o.strip() for o in options.split(",") if o.strip()][:10]
    if len(option_list) < 2:
        return RedirectResponse(f"/dashboard/{guild_id}/umfragen", status_code=303)

    user = _current_user(request)
    poll = await create_poll(guild_id, channel_id, question, option_list, int(user["discord_id"]))

    number_emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
    description_lines = [f"{number_emojis[i]} {opt}" for i, opt in enumerate(option_list)]
    embed = {
        "title": f"📊 {question}", "description": "\n".join(description_lines),
        "color": 0x7c5cff, "footer": {"text": f"Umfrage #{poll.id} — reagiere zum Abstimmen"},
    }
    message_id = await send_channel_embed_get_id(channel_id, embed)
    if message_id:
        await set_poll_message_id(poll.id, message_id)
        for i in range(len(option_list)):
            await add_message_reaction(channel_id, message_id, number_emojis[i])
    return RedirectResponse(f"/dashboard/{guild_id}/umfragen", status_code=303)
