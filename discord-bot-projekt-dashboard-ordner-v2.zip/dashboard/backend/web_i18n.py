"""
Übersetzungen für die WEBSITE selbst (Startseite, Apply, News, Serverliste,
Navigation) -- getrennt von bot/utils/i18n.py, das die Antworten des
Discord-Bots übersetzt. Englisch ist der Standard.

Bewusst NUR Englisch + Deutsch (kein Spanisch mehr) -- eine frühere Version
mit 3 Sprachen ist beim manuellen Hochladen über GitHub mehrfach an
abgebrochenen Kopiervorgängen gescheitert (SyntaxError, Seite komplett
down). Kleinere Datei = zuverlässiger zu kopieren.
"""

WEB_TRANSLATIONS = {
    "en": {
        "nav_apply": "Apply",
        "nav_news": "News",
        "nav_admin_panel": "Admin Panel",
        "nav_logout": "Logout",
        "footer_join_discord": "Join our Discord",

        "landing_title": "Your Discord Bot, fully in control",
        "landing_subtitle": "Moderation, team management, music, tickets, applications and more — "
                             "all in one place, for every server where you're an admin.",
        "landing_btn_dashboard": "Go to Server Dashboard",
        "landing_btn_admin": "Go to Admin Area",

        "feature1_title": "Moderation & Security",
        "feature1_desc": "Anti-Nuke, Anti-Spam, Anti-Hack, Anti-Advertising, team ranks and a full punishment register.",
        "feature2_title": "Music & Radio",
        "feature2_desc": "YouTube playback and real live radio stations, always on in your voice channel.",
        "feature3_title": "Tickets & Waiting Room",
        "feature3_desc": "Professional support panels with multiple designs and automatic help detection.",
        "feature4_title": "Application System",
        "feature4_desc": "Your own application forms for your team — applicants fill them out right here.",
        "feature5_title": "Level & Community",
        "feature5_desc": "XP system, invite tracking and giveaways — make activity on your server visible.",
        "feature6_title": "Multilingual & Autorole",
        "feature6_desc": "German or English per server, automatic role assignment for members, bots and admins.",

        "apply_title": "Apply for our Team",
        "apply_subtitle": "Want to help out? Apply directly on our Discord server — we review every application personally.",
        "apply_btn": "Join our Discord & Apply",
        "apply_step1_title": "Join the Discord",
        "apply_step1_desc": "Click the button above to join our official Discord server.",
        "apply_step2_title": "Find the Application",
        "apply_step2_desc": "Look for our application channel or check the server dashboard for an application form.",
        "apply_step3_title": "Get Reviewed",
        "apply_step3_desc": "Our team reviews applications personally and will get back to you.",

        "news_title": "News",
        "news_empty": "No news yet.",

        "guilds_title": "Your Servers",
        "guilds_subtitle": "Servers where you have admin rights:",
        "guilds_manage_btn": "Manage",
        "guilds_invite_btn": "Invite Bot",
        "guilds_empty": "You don't have anything to manage yet.",

        "lang_switch_label": "Language",
    },
    "de": {
        "nav_apply": "Bewerben",
        "nav_news": "News",
        "nav_admin_panel": "Admin-Panel",
        "nav_logout": "Logout",
        "footer_join_discord": "Unserem Discord beitreten",

        "landing_title": "Dein Discord-Bot, komplett unter Kontrolle",
        "landing_subtitle": "Moderation, Team-Verwaltung, Musik, Tickets, Bewerbungen und mehr — "
                             "alles an einem Ort, für jeden Server, auf dem du Admin bist.",
        "landing_btn_dashboard": "Zum Server-Dashboard",
        "landing_btn_admin": "Zum Admin-Bereich",

        "feature1_title": "Moderation & Sicherheit",
        "feature1_desc": "Anti-Nuke, Anti-Spam, Anti-Hack, Anti-Werbung, Team-Ränge und ein vollständiges Strafregister.",
        "feature2_title": "Musik & Radio",
        "feature2_desc": "YouTube-Wiedergabe und echte Live-Radiosender, dauerhaft in deinem Sprachkanal.",
        "feature3_title": "Tickets & Warteraum",
        "feature3_desc": "Professionelle Support-Panels mit mehreren Designs und automatischer Hilfe-Erkennung.",
        "feature4_title": "Bewerbungssystem",
        "feature4_desc": "Eigene Bewerbungsformulare für dein Team — Bewerber:innen füllen sie direkt hier aus.",
        "feature5_title": "Level & Community",
        "feature5_desc": "XP-System, Invite-Tracking und Gewinnspiele — Bewegung und Beteiligung sichtbar machen.",
        "feature6_title": "Mehrsprachig & Autorole",
        "feature6_desc": "Deutsch oder Englisch pro Server, automatische Rollenvergabe für Mitglieder, Bots und Admins.",

        "apply_title": "Bewirb dich für unser Team",
        "apply_subtitle": "Willst du mithelfen? Bewirb dich direkt auf unserem Discord-Server — wir prüfen jede Bewerbung persönlich.",
        "apply_btn": "Discord beitreten & bewerben",
        "apply_step1_title": "Discord beitreten",
        "apply_step1_desc": "Klick auf den Button oben, um unserem offiziellen Discord-Server beizutreten.",
        "apply_step2_title": "Bewerbung finden",
        "apply_step2_desc": "Schau nach unserem Bewerbungs-Kanal oder im Server-Dashboard nach einem Bewerbungsformular.",
        "apply_step3_title": "Geprüft werden",
        "apply_step3_desc": "Unser Team prüft Bewerbungen persönlich und meldet sich bei dir.",

        "news_title": "News",
        "news_empty": "Noch keine News.",

        "guilds_title": "Deine Server",
        "guilds_subtitle": "Server, auf denen du Admin-Rechte hast:",
        "guilds_manage_btn": "Verwalten",
        "guilds_invite_btn": "Bot einladen",
        "guilds_empty": "Du hast noch nichts zu verwalten.",

        "lang_switch_label": "Sprache",
    },
}


def wt(lang: str, key: str) -> str:
    """Website-Übersetzung. Fällt auf Englisch zurück, wenn die Sprache oder
    der Schlüssel unbekannt ist -- nie ein kaputtes {{ ... }} auf der Seite."""
    return WEB_TRANSLATIONS.get(lang, WEB_TRANSLATIONS["en"]).get(
        key, WEB_TRANSLATIONS["en"].get(key, key)
    )
